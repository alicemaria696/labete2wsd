document.getElementById('b1').addEventListener('click', async function() {
    try {
        const response = await fetch('cat.json');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        const selectElement = document.getElementById('cat');
        selectElement.innerHTML = ''; 
        const imageContainer = document.getElementById('image-container');
        imageContainer.innerHTML = ''; 

        data.forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.text = `${item.name} ,${item.temperament}, ${item.origin}`;
            selectElement.appendChild(option);

            const img = document.createElement('img');
            img.src = item.image;
            img.alt = item.name;
            imageContainer.appendChild(img);
        });
    } catch (error) {
        console.error('Error fetching data:', error);
    }
});